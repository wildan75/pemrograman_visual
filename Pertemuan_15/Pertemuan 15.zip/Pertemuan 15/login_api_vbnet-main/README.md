# Login VB Net berbasis API
#### VB Net
###### Visual Studio 2015
#### XAMPP
###### XAMPP 3.2.4
#### PHP
###### PHP 7.4.13
#### Database
###### MariaDb 10.4.17
