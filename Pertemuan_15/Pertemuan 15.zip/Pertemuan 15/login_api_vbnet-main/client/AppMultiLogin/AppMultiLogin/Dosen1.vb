﻿Public Class Dosen1

End Class