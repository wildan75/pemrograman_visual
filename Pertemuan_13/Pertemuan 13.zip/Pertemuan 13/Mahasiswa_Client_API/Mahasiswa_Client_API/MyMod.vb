﻿Module MyMod
    Public api_folder As String = "appakademik"
    Public mahasiswa_api As String = "http://f0833858.xsph.ru/" & api_folder & "/mahasiswa_api.php/"
    Public mahasiswa_baru As Boolean
End Module