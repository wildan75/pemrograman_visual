﻿Public Class Mahasiswa
    Public Property nim As String
    Public Property nama As String
    Public Property jk As String
    Public Property prodi As String

End Class
