﻿Module MyMod
    Public api_folder As String = "appakademik"
    Public pasien_api As String = "http://f0833858.xsph.ru/" & api_folder & "/pasien_api.php/"
    Public pasien_baru As Boolean
End Module
