﻿Module MyMod
    Public api_folder As String = "appakademik"
    Public dokter_api As String = "http://f0833858.xsph.ru/" & api_folder & "/dokter_api.php/"
    Public dokter_baru As Boolean
End Module
