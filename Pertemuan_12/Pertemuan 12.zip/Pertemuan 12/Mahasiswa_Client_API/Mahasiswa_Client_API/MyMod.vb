﻿Module MyMod
    Public api_folder As String = "appakademik"
    Public mahasiswa_api As String = "http://localhost/" & api_folder & "/mahasiswa_api.php/"
    Public mahasiswa_baru As Boolean
End Module
